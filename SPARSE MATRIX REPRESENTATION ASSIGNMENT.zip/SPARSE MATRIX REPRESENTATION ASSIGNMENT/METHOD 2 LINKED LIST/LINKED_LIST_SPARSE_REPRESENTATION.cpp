//C++ program for Sparce matrix representation
//@METHOD 2: Using Link List
#include <iostream>
using namespace std;

//Node class to represent link list
class Node
{
	public:
		int row;
		int col;
		int data;
		Node *link;
		Node(){
			
		}
};

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
//Function to create new node
void create_new_node(Node * &p, int row_index,
                     int col_index, int data)
{
	Node *temp = p;
	Node *r;
	
	//if link list is empty then create first node and assign value.
	if (temp == NULL)
	{
		temp = new Node();
		temp->row = row_index;
		temp->col = col_index;
		temp->data = data;
		temp->link = NULL;
		p = temp;
		
	}
	
	//If link list is already created then append newly created node
	else
	{
		while (temp->link != NULL)
		     temp = temp->link;
		     
		r = new Node();
		r->row = row_index;
		r->col = col_index;
		r->data = data;
		r->link = NULL;
		temp->link = r;
		
	}
}

//Function prints contents of linked list starting from start
void printList(Node *start)
{
	cout<<"\n\n Linked List representation of Sparse Matrix \n\n";
	Node *ptr = start;
	cout<< "\trow_position    :   ";
	while (ptr != NULL)
	{
		cout<< ptr->row << " ";
		ptr = ptr->link;
	}
	cout<< endl;
	cout<< "\tcolumn_position :   ";
	
	ptr = start;
	while (ptr != NULL)
	{
		cout<< ptr->col << " ";
		ptr = ptr->link;	
	}
	cout<< endl;
	cout<< "\tValue           :   ";
	ptr = start;
	
	while (ptr != NULL)
	{
		cout<< ptr->data << " ";
		ptr = ptr->link;	
	}
	cout<<endl<<endl<<endl<<endl;
}

//Driver Code//@tituskigunda04@gmail.com
int main() {
	//4*5 sparce matrix
	int sparseMatrix[4][5] = { { 0 , 0 , 3 , 0 , 4 },
	                           { 0 , 0 , 5 , 7 , 0 },
							   { 0 , 0 , 0 , 0 , 0 },
							   { 0 , 2 , 6 , 0 , 0 } };
    //Creating head/start node of list as NULL
    Node *start = NULL;
    for(int i = 0; i < 4; i++)
    {
    for(int j = 0; j < 5; j++)	
    {
    	//pass only those values which are non-zero
    	if(sparseMatrix[i][j] != 0)
    	   create_new_node(start, i, j,
		                   sparseMatrix[i][j]); 
    	
	}
	}
	printList(start);
	
	return 0;
}

