//C++ program for Sparse matrix representation
//METHOD 1: Uisng Array

#include <iostream>

using namespace std;

int main()
{
    // Assume 4 * 5 sparse matrix
    int sparseMatrix[4][5] =
    { 
        { 0 , 0 , 3 , 0 , 4 },
        { 0 , 0 , 5 , 7 , 0 },
        { 0 , 0 , 0 , 0 , 0 },
        { 0 , 2 , 6 , 0 , 0 } 
    }; 

    int size = 0;
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 5; j++)
            if (sparseMatrix[i][j] != 0)
                size++;

    // Number of columns in compactMatrix (size) must be equal to the number of 
    // non-zero elements in sparseMatrix
    int compactMatrix[3][size];

    // Making of the new matrix
    int k = 0;

    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 5; j++)
            if (sparseMatrix[i][j] != 0)
            {
                compactMatrix[0][k] = i;
                compactMatrix[1][k] = j;
                compactMatrix[2][k] = sparseMatrix[i][j];
                k++;
            }

    cout << "Row      ";
    for (int i = 0; i < size; i++)
        cout << compactMatrix[0][i] << "   ";

    cout << "\nColumn   ";
    for (int i = 0; i < size; i++)
        cout << compactMatrix[1][i] << "   ";

    cout << "\nValue    ";
    for (int i = 0; i < size; i++)
        cout << compactMatrix[2][i] << "   ";

    return 0;
}

